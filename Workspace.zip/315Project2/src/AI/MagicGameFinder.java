package AI;

/*
 * Finds game setups (staring board) than can be finished entirely in 1 turn.
 * Never had time to implement this (and it is not required), but here are examples:
1
2 1
3 2 1
4 2 0 0
5 3 1 1 0
8 6 4 2 0 1 1 0
 */

public class MagicGameFinder {
	public static void main(String... args){
//		Board board = new Board(6, 4);
	}
}
