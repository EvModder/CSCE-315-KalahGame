package old.Main;


interface KalahSquare{
	abstract void addSeeds(int i);
	abstract void setSeeds(int i);
	abstract int getSeeds();
}
