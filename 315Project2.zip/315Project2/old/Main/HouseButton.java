package old.Main;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;


public class HouseButton extends JButton implements KalahSquare{
	private static final long serialVersionUID = 1L;
	int seeds;

	public HouseButton(int i, int initialSeeds){
		super(""+initialSeeds);
		seeds = initialSeeds;
		addActionListener(new ButtonListener(i));
		setEnabled(false);
	}
	
	class ButtonListener implements ActionListener{
		int idx;
		ButtonListener(int i){
			idx = i;
		}
		@Override public void actionPerformed(ActionEvent evt){
			synchronized(KalahGame.move){
				if(KalahGame.move == -1){
					KalahGame.move = idx;
					System.out.println("Button"+idx+" pressed");
				}
			}
		}
	};
	
	@Override
	public void setSeeds(int i) {
		seeds = i;
		setText(""+i);
	}

	@Override
	public int getSeeds() {
		return seeds;
	}
	
	@Override
	public void addSeeds(int i) {
		setSeeds(i+seeds);
	}
}