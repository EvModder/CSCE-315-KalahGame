package old.AI;
import java.util.ArrayList;
import java.util.List;

import old.Main.Utils;
import old.Main.Utils.TimerListener;

public class MinMaxAI extends AI{
	boolean weHaveTime;
	List<Integer> moves = new ArrayList<Integer>();
	
	int numHouses;
	
	@Override
	public List<Integer> getMove(int[] board, int timelimit){
		moves.clear();
		numHouses = board.length/2-1;
		
		weHaveTime = true;
		Utils.startTimer(new TimerListener(){
			@Override public void timerEnded() {
				weHaveTime = false;
			}
		}, timelimit-1000);//1 second buffer to account for network lag
		
		new Thread(){
			@Override public void run(){
				//generate tree, add moves
			}
		}.start();
		
		while(weHaveTime) Thread.yield();
		return moves;
	}
	
	@Override
	public boolean doPieRule(int[] board, int timelimit){
		return true;
	}
	
	//TODO: modify this as you see fit!
	public int utilityFunction(int[] board){
		//my kalah - your kalah
		return board[numHouses] - board[board.length-1];
	}
}