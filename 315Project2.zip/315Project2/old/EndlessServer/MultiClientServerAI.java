package old.EndlessServer;
import java.awt.Color;
import java.awt.Font;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import old.Main.Settings;
import old.ServerUtils.Connection;
import old.ServerUtils.MultiServer;
import old.ServerUtils.MultiServer.ConnectionReceiver;

class MultiClientServerAI implements ConnectionReceiver{
	/*
	 * A multi-client version of EndlessServerAI. This version waits for client
	 * connections and starts a new game with each new connection it receives.
	 */
	Random rand = new Random();
	
	public static void main(String... args){
		Settings.changeSetting("play-as-AI", "true");
		
		//Show nice GUI, closing this GUI will be a way to terminate the program
		JFrame window = new JFrame("MultiClientServerAI");
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setIconImage(new ImageIcon(MultiClientServerAI.class.getResource("/seeds.png")).getImage());
		window.setSize(320, 120);
		window.setResizable(false);
		JLabel label = new JLabel("MultiClientServerAI is running", SwingConstants.CENTER);
		label.setBackground(new Color(40,160,20));
		label.setForeground(new Color(200,255,255));
		label.setOpaque(true);
		label.setFont(new Font("Consolas", Font.BOLD, 16));
		window.add(label);
		window.setLocationRelativeTo(null);
		window.setVisible(true);
		
		new MultiServer(new MultiClientServerAI());
	}

	@Override
	public void gotConnection(Connection connection){
		new Thread(){@Override public void run(){
			Settings.changeSetting("holes-per-side", String.valueOf(rand.nextInt(9)+2));
			Settings.changeSetting("seeds-per-hole", String.valueOf(rand.nextInt(10)+1));
			Settings.changeSetting("time-limit", String.valueOf(rand.nextInt(49001)+1000));
			Settings.changeSetting("starting-player", rand.nextBoolean() ? "S" : "F");
			
			KalahNoGUI game = new KalahNoGUI(true, connection);
			while(!game.gameOver) Thread.yield();
			
		}}.start();
	}
}