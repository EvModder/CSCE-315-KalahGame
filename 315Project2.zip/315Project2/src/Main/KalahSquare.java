package Main;

public interface KalahSquare{
	abstract void addSeeds(int i);
	abstract void setSeeds(int i);
	abstract int getSeeds();
}
