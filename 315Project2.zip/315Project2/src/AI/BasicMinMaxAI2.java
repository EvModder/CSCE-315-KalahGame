package AI;
import java.util.ArrayList;
import java.util.List;
import Main.Board;

public class BasicMinMaxAI2 extends KalahPlayer{
	StrategicAI utility;
	boolean waitingForOpp=true, hasTime, buildingTree;
	long turn, timeLimit, timeBuffer;
	int MAX_DEPTH = 7;
	Node root;
	
	int floorLogBaseX(int x, int val){
		int count=0;
		long n=1;
		while(n < val){
			n *= x;
			++count;
		}
		return count;
	}
	
	public BasicMinMaxAI2(Board board){
		super(board);
		utility = new StrategicAI(null);
		MAX_DEPTH = floorLogBaseX(board.numHouses, 1000000);
	}
	
	@Override public void updateTimer(long time){
		if(time > timeLimit){
			timeLimit = time;
			timeBuffer = timeLimit-1000;//Math.min(timeLimit/5 + 10, 750);
		}
		else if(time < timeBuffer) hasTime = false;
	}
	
	@Override public List<Integer> getMove(){
		if(hasTime) return null;
		++turn;
		
		hasTime = true;
		new Thread(){@Override public void run(){
			if(root == null) root = new Node(board, true, null, 0);
			int d = MAX_DEPTH;
			buildingTree = true;
			while(hasTime)
				root.makeKids(d++, turn);
			buildingTree = false;
			System.out.println("done building tree");
		}}.start();
		
		while(hasTime || buildingTree) Thread.yield();
		
		List<Integer> moves = new ArrayList<Integer>();
		int move, land;
		do{
			root.makeKids(MAX_DEPTH-2, turn);
			moves.add(move = root.bestMove);
			root = root.getChild(move);
			land = board.moveSeeds(move);
		} while(land == board.kalah1() && board.gameNotOver());
		
		waitingForOpp = true;
		return moves;
	}

	@Override public void applyOpponentMove(int move){
		int land = board.moveSeeds(move);
		++turn;
		
		if(root == null){
			root = new Node(board, land != board.kalah2, null, 0);
		}
		else{
			root.makeKids(MAX_DEPTH-2, turn);
			root = root.getChild(move);
		}
		
		if(waitingForOpp){++turn; waitingForOpp = false;}
//		System.out.println("Player1: "+root.myTurn);
	}
	
	class Node{
		Node(Board board, boolean max, Node p, int move){
			state=board; myTurn=max;
			parent = p;
			this.move = move;
		}
		int bestValue, bestMove = -444;//magic value
		Board state;
		Node[] children;
		Node parent;
		boolean myTurn, hasKids, updated;
		int move;
		
		void updateValue(){
			updated = true;
			if(myTurn){
				bestValue = Integer.MIN_VALUE;
				for(Node child : children){
					if(child.bestValue > bestValue){
						bestValue = child.bestValue;
						bestMove = child.move;
					}
				}
			}
			else{
				bestValue = Integer.MAX_VALUE;
				for(Node child : children){
					if(child.bestValue < bestValue){
						bestValue = child.bestValue;
						bestMove = child.move;
					}
				}
			}
			if(parent != null && parent.hasKids){
				parent.updateValue();
			}
		}
		
		Node getChild(int move){
			for(Node child : children) if(child.move == move) return child;
			return null;
		}
		
		void makeKids(int depth, long turn){
			if(depth == 0){
				bestValue = state.getScoreDifference();
				//TODO: Instead of return, wait for parent to update, then set depth=0 and continue
				if(parent.hasKids) parent.updateValue();
				return;
			}
			if(hasKids){
				--depth;
				for(Node child : children){
					if(myTurn != child.myTurn) child.makeKids(depth, turn+1);
					else child.makeKids(depth, turn);
				}
				updateValue();
				return;
			}
			if(bestMove == -100 || !state.gameNotOver()){//-100 = magic number
				state.collectLeftoverSeeds();
				bestValue = state.getScoreDifference();
				bestMove = -100;
				if(parent.hasKids) parent.updateValue();
				return;
			}
			
			List<Integer> moves = state.getPossibleMoves(myTurn, turn);
			children = new Node[moves.size()];
			
			int i = -1;
			for(int move : moves){
				Board newState = state.getCopy();
				int land = newState.moveSeeds(move);
				boolean newTurn;
				if(myTurn) newTurn = (land == state.kalah1());
				else newTurn = (land != state.kalah2);
				children[++i] = new Node(newState, newTurn, this, move);
			}
			--depth;
			for(Node child : children){
				if(myTurn != child.myTurn) child.makeKids(depth, turn+1);
				else child.makeKids(depth, turn);
			}
			hasKids = true;
		}
	}
}