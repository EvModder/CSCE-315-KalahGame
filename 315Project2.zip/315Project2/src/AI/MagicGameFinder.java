package AI;

public class MagicGameFinder {
	public static void main(String... args){
//		Board board = new Board(6, 4);
	}
}
