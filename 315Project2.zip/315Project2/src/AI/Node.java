package AI;

public class Node{

}
